# XITERS X Mobile — Android / C++ / Dear ImGui

Versão mobile do XITERS X com tema dourado e preto, feita para Android NDK e Dear ImGui. É um **simulador visual independente**, com alvos fictícios. Não se conecta ao Free Fire/GameLoop, não lê memória de outros processos e não faz overlay sobre jogos.

## Recursos
- Interface adaptada a toque
- FOV visual ajustável de 0 a 100
- Retículo de treino
- ESP demonstrativo para alvos fictícios, com nomes e distâncias simuladas
- Controles para ligar/desligar os elementos

## Dependências
- Android Studio recente
- Android SDK + Android NDK
- CMake
- Dear ImGui (código-fonte oficial)

## Configuração
1. Baixe Dear ImGui: https://github.com/ocornut/imgui
2. Copie o conteúdo do repositório para `external/imgui/`, incluindo `backends/`.
3. Abra a pasta do projeto no Android Studio.
4. Aguarde a sincronização do Gradle e compile para um dispositivo Android.

O projeto usa `NativeActivity`, OpenGL ES 3 e o backend Android do Dear ImGui. A pasta `external/imgui/` fica vazia no ZIP por causa da dependência externa.

## Build pela linha de comando
Com Android SDK/NDK configurados:
```bash
gradle assembleDebug
```
O APK de debug, se a compilação terminar sem erros, ficará em `app/build/outputs/apk/debug/`.

## Observação
Este ZIP contém o código-fonte e a configuração de build, não um APK pré-compilado. A compilação requer as dependências listadas acima.
