#include <android/log.h>
#include <android_native_app_glue.h>
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <algorithm>
#include <cstdio>
#include <cmath>
#include "imgui.h"
#include "imgui_impl_android.h"
#include "imgui_impl_opengl3.h"

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "XITERSX", __VA_ARGS__)

struct Engine {
    android_app* app = nullptr;
    EGLDisplay display = EGL_NO_DISPLAY;
    EGLSurface surface = EGL_NO_SURFACE;
    EGLContext context = EGL_NO_CONTEXT;
    int width = 0, height = 0;
    bool ready = false;
};

static float fov = 55.0f;
static bool show_fov = true, show_esp = true, show_names = true;
static bool show_distances = true, show_crosshair = true;
static bool show_training = true;

static void theme_gold_black() {
    ImGuiStyle& s = ImGui::GetStyle();
    s.WindowRounding = 12; s.ChildRounding = 10; s.FrameRounding = 8;
    s.GrabRounding = 8; s.ScrollbarRounding = 8;
    s.WindowPadding = ImVec2(16,16); s.FramePadding = ImVec2(12,10);
    s.ItemSpacing = ImVec2(12,12);
    ImVec4* c = s.Colors;
    c[ImGuiCol_Text] = ImVec4(.94f,.94f,.94f,1);
    c[ImGuiCol_TextDisabled] = ImVec4(.55f,.55f,.58f,1);
    c[ImGuiCol_WindowBg] = ImVec4(.035f,.035f,.04f,1);
    c[ImGuiCol_ChildBg] = ImVec4(.065f,.065f,.07f,1);
    c[ImGuiCol_Border] = ImVec4(.45f,.32f,.07f,.75f);
    c[ImGuiCol_FrameBg] = ImVec4(.12f,.12f,.13f,1);
    c[ImGuiCol_FrameBgHovered] = ImVec4(.30f,.23f,.08f,1);
    c[ImGuiCol_FrameBgActive] = ImVec4(.40f,.30f,.08f,1);
    c[ImGuiCol_CheckMark] = ImVec4(1,.77f,.16f,1);
    c[ImGuiCol_SliderGrab] = ImVec4(.94f,.68f,.10f,1);
    c[ImGuiCol_SliderGrabActive] = ImVec4(1,.82f,.25f,1);
    c[ImGuiCol_Button] = ImVec4(.26f,.19f,.055f,1);
    c[ImGuiCol_ButtonHovered] = ImVec4(.43f,.31f,.07f,1);
    c[ImGuiCol_ButtonActive] = ImVec4(.57f,.40f,.08f,1);
    c[ImGuiCol_Header] = ImVec4(.26f,.19f,.055f,1);
    c[ImGuiCol_HeaderHovered] = ImVec4(.43f,.31f,.07f,1);
    c[ImGuiCol_HeaderActive] = ImVec4(.57f,.40f,.08f,1);
}

static int32_t handle_input(android_app* app, AInputEvent* event) {
    return ImGui_ImplAndroid_HandleInputEvent(event);
}

static bool init_display(Engine& e) {
    const EGLint attribs[] = {
        EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT,
        EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
        EGL_BLUE_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_RED_SIZE, 8,
        EGL_DEPTH_SIZE, 16, EGL_NONE
    };
    e.display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    if (e.display == EGL_NO_DISPLAY || !eglInitialize(e.display, nullptr, nullptr)) return false;
    EGLConfig config;
    EGLint count;
    if (!eglChooseConfig(e.display, attribs, &config, 1, &count) || count == 0) return false;
    EGLint format;
    eglGetConfigAttrib(e.display, config, EGL_NATIVE_VISUAL_ID, &format);
    ANativeWindow_setBuffersGeometry(e.app->window, 0, 0, format);
    const EGLint ctx_attrs[] = { EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE };
    e.context = eglCreateContext(e.display, config, EGL_NO_CONTEXT, ctx_attrs);
    e.surface = eglCreateWindowSurface(e.display, config, e.app->window, nullptr);
    if (e.context == EGL_NO_CONTEXT || e.surface == EGL_NO_SURFACE) return false;
    if (eglMakeCurrent(e.display, e.surface, e.surface, e.context) != EGL_TRUE) return false;
    eglQuerySurface(e.display, e.surface, EGL_WIDTH, &e.width);
    eglQuerySurface(e.display, e.surface, EGL_HEIGHT, &e.height);
    e.ready = true;
    return true;
}

static void shutdown_display(Engine& e) {
    if (e.display != EGL_NO_DISPLAY) {
        eglMakeCurrent(e.display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (e.context != EGL_NO_CONTEXT) eglDestroyContext(e.display, e.context);
        if (e.surface != EGL_NO_SURFACE) eglDestroySurface(e.display, e.surface);
        eglTerminate(e.display);
    }
    e.display = EGL_NO_DISPLAY; e.context = EGL_NO_CONTEXT; e.surface = EGL_NO_SURFACE;
    e.ready = false;
}

static void draw_training() {
    ImGui::BeginChild("Treino", ImVec2(0, 0), true);
    ImVec2 p = ImGui::GetCursorScreenPos();
    ImVec2 sz = ImGui::GetContentRegionAvail();
    sz.x = std::max(100.0f, sz.x); sz.y = std::max(140.0f, sz.y);
    ImDrawList* dl = ImGui::GetWindowDrawList();
    dl->AddRectFilled(p, ImVec2(p.x+sz.x,p.y+sz.y), IM_COL32(14,15,18,255), 8);
    for(float x=p.x; x<p.x+sz.x; x+=32) dl->AddLine(ImVec2(x,p.y),ImVec2(x,p.y+sz.y),IM_COL32(42,42,45,120));
    for(float y=p.y; y<p.y+sz.y; y+=32) dl->AddLine(ImVec2(p.x,y),ImVec2(p.x+sz.x,y),IM_COL32(42,42,45,120));
    ImVec2 center(p.x+sz.x*.5f,p.y+sz.y*.5f);
    if(show_fov) dl->AddCircle(center, 18.0f + fov/100.0f*std::min(sz.x,sz.y)*.42f, IM_COL32(242,193,54,220), 80, 2.5f);
    if(show_crosshair) {
        dl->AddLine(ImVec2(center.x-13,center.y),ImVec2(center.x-4,center.y),IM_COL32(255,210,70,255),2);
        dl->AddLine(ImVec2(center.x+4,center.y),ImVec2(center.x+13,center.y),IM_COL32(255,210,70,255),2);
        dl->AddLine(ImVec2(center.x,center.y-13),ImVec2(center.x,center.y-4),IM_COL32(255,210,70,255),2);
        dl->AddLine(ImVec2(center.x,center.y+4),ImVec2(center.x,center.y+13),IM_COL32(255,210,70,255),2);
    }
    const float xs[] = {.22f,.48f,.76f}, ys[] = {.34f,.55f,.37f};
    const char* names[] = {"ALVO A","ALVO B","ALVO C"};
    const char* dists[] = {"18 m","27 m","34 m"};
    if(show_esp) for(int i=0;i<3;i++) {
        ImVec2 c(p.x+sz.x*xs[i],p.y+sz.y*ys[i]);
        dl->AddRect(ImVec2(c.x-18,c.y-31),ImVec2(c.x+18,c.y+31),IM_COL32(242,193,54,255),3,0,2);
        dl->AddCircle(ImVec2(c.x,c.y-38),5,IM_COL32(242,193,54,255),16,2);
        if(show_names) dl->AddText(ImVec2(c.x-22,c.y+35),IM_COL32(245,245,245,255),names[i]);
        if(show_distances) dl->AddText(ImVec2(c.x-13,c.y+50),IM_COL32(242,193,54,255),dists[i]);
    }
    dl->AddText(ImVec2(p.x+10,p.y+10),IM_COL32(170,170,175,255),"SIMULADOR | ALVOS FICTICIOS");
    ImGui::Dummy(sz);
    ImGui::EndChild();
}

static void frame(Engine& e) {
    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplAndroid_NewFrame();
    ImGui::NewFrame();
    ImGui::SetNextWindowPos(ImVec2(0,0));
    ImGui::SetNextWindowSize(ImVec2((float)e.width,(float)e.height));
    ImGui::Begin("XITERS X MOBILE", nullptr,
        ImGuiWindowFlags_NoResize|ImGuiWindowFlags_NoMove|ImGuiWindowFlags_NoCollapse);
    ImGui::TextColored(ImVec4(1,.78f,.20f,1),"XITERS X");
    ImGui::SameLine();
    ImGui::TextDisabled("MOBILE TRAINING LAB");
    ImGui::Separator();

    if(ImGui::BeginTabBar("main_tabs")) {
        if(ImGui::BeginTabItem("TREINO")) {
            ImGui::Checkbox("FOV visual",&show_fov);
            ImGui::SameLine();
            ImGui::Checkbox("Mira",&show_crosshair);
            ImGui::SliderFloat("Tamanho FOV",&fov,0,100,"%.0f");
            ImGui::Checkbox("ESP ficticio",&show_esp);
            ImGui::SameLine();
            ImGui::Checkbox("Nomes",&show_names);
            ImGui::SameLine();
            ImGui::Checkbox("Distancias",&show_distances);
            draw_training();
            ImGui::EndTabItem();
        }
        if(ImGui::BeginTabItem("ESP")) {
            ImGui::TextWrapped("Este ESP desenha somente tres alvos de teste locais. Nao mostra jogadores reais.");
            ImGui::Checkbox("Mostrar caixas",&show_esp);
            ImGui::Checkbox("Mostrar nomes",&show_names);
            ImGui::Checkbox("Mostrar distancias",&show_distances);
            draw_training();
            ImGui::EndTabItem();
        }
        if(ImGui::BeginTabItem("SOBRE")) {
            ImGui::Text("XITERS X Mobile - v1.0");
            ImGui::TextWrapped("Simulador independente para Android. Nao se conecta ao Free Fire, nao le memoria de outros apps e nao oferece aimbot funcional.");
            ImGui::BulletText("C++17 + Dear ImGui");
            ImGui::BulletText("Android NDK + OpenGL ES 3");
            ImGui::BulletText("Interface dourada e preta");
            ImGui::EndTabItem();
        }
        ImGui::EndTabBar();
    }
    ImGui::End();
    ImGui::Render();
    glViewport(0,0,e.width,e.height);
    glClearColor(.025f,.025f,.03f,1);
    glClear(GL_COLOR_BUFFER_BIT);
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    eglSwapBuffers(e.display,e.surface);
}

static void handle_cmd(android_app* app, int32_t cmd) {
    Engine* e = (Engine*)app->userData;
    if (!e) return;
    switch(cmd) {
        case APP_CMD_INIT_WINDOW:
            if(app->window && !e->ready) init_display(*e);
            break;
        case APP_CMD_TERM_WINDOW:
            shutdown_display(*e);
            break;
    }
}

void android_main(android_app* app) {
    app_dummy();
    Engine engine;
    engine.app = app;
    app->userData = &engine;
    app->onAppCmd = handle_cmd;
    app->onInputEvent = handle_input;

    while(true) {
        int events;
        android_poll_source* source;
        while(ALooper_pollOnce(engine.ready ? 0 : -1, nullptr, &events, (void**)&source) >= 0) {
            if(source) source->process(app, source);
            if(app->destroyRequested) {
                shutdown_display(engine);
                return;
            }
        }
        if(engine.ready) {
            static bool imgui_ready = false;
            if(!imgui_ready) {
                IMGUI_CHECKVERSION();
                ImGui::CreateContext();
                ImGuiIO& io = ImGui::GetIO();
                io.IniFilename = nullptr;
                io.FontGlobalScale = 1.15f;
                theme_gold_black();
                ImGui_ImplAndroid_Init(app->window);
                ImGui_ImplOpenGL3_Init("#version 300 es");
                imgui_ready = true;
            }
            eglQuerySurface(engine.display,engine.surface,EGL_WIDTH,&engine.width);
            eglQuerySurface(engine.display,engine.surface,EGL_HEIGHT,&engine.height);
            frame(engine);
        }
    }
}
